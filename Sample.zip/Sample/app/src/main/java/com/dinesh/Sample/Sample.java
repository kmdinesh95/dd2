package com.dinesh.Sample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Sample extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sample);
    }
}
